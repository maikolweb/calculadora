package com.clase.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    String operador = "";
    String operando1 = "";
    String temporal = "";
    TextView resultado;
    Button mas, res, mul, div, igu, pun,tan,cos,sec;

    Double op1 = 0.0;
    Double op2 = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        resultado = (TextView) findViewById(R.id.pantalla);


        Button boton0 = (Button) findViewById(R.id.button0);
        boton0.setOnClickListener(this);

        Button boton1 = (Button) findViewById(R.id.button1);
        boton1.setOnClickListener(this);

        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(this);

        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(this);

        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(this);

        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(this);

        Button button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(this);

        Button button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(this);

        Button button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(this);

        Button button9 = (Button) findViewById(R.id.button9);
        button9.setOnClickListener(this);

        mas = (Button) findViewById(R.id.mas);
        mas.setOnClickListener(this);

        res = (Button) findViewById(R.id.res);
        res.setOnClickListener(this);

        mul = (Button) findViewById(R.id.mul);
        mul.setOnClickListener(this);

        div = (Button) findViewById(R.id.div);
        div.setOnClickListener(this);

        igu = (Button) findViewById(R.id.igu);
        igu.setOnClickListener(this);

        pun = (Button) findViewById(R.id.pun);
        pun.setOnClickListener(this);

        tan = (Button) findViewById(R.id.tan);
        tan.setOnClickListener(this);

        cos = (Button) findViewById(R.id.cos);
        cos.setOnClickListener(this);

        sec = (Button) findViewById(R.id.sec);
        sec.setOnClickListener(this);

        Button clr = (Button) findViewById(R.id.clr);
        clr.setOnClickListener(this);


    }


    public void onClick(View v) {
        temporal = resultado.getText().toString();


        switch (v.getId()) {
            case R.id.button0:
                resultado.setText(temporal + "0");
                break;
            case R.id.button1:
                resultado.setText(temporal + "1");
                break;
            case R.id.button2:

                resultado.setText(temporal + "2");
                break;
            case R.id.button3:
                resultado.setText(temporal + "3");
                break;
            case R.id.button4:
                resultado.setText(temporal + "4");
                break;
            case R.id.button5:
                resultado.setText(temporal + "5");
                break;
            case R.id.button6:
                resultado.setText(temporal + "6");
                break;
            case R.id.button7:
                resultado.setText(temporal + "7");
                break;
            case R.id.button8:
                resultado.setText(temporal + "8");
                break;
            case R.id.button9:
                resultado.setText(temporal + "9");
                break;
            case R.id.pun:
                    resultado.setText(temporal + ".");
                break;

            case R.id.tan:
                resultado.setText(temporal + "tan(");
                break;

            case R.id.mas:
                operando1 = temporal;
                operador = "mas";
                habilitar(false);
                clear();
                break;

            case R.id.res:
                operando1 = temporal;
                operador = "res";
                habilitar(false);
                clear();
                break;

            case R.id.mul:
                operando1 = temporal;
                operador = "mul";
                habilitar(false);
                clear();
                break;

            case R.id.div:
                operando1 = temporal;
                operador = "div";
                habilitar(false);
                clear();
                break;

            case R.id.igu:
                calcular(operador, operando1, temporal);
                habilitar(true);
                break;

            case R.id.clr:
                clear();
                habilitar(true);
                break;

        }


    }

    public void clear() {

        resultado.setText("");
    }


    public void calcular(String operador, String operando1, String temporal) {

        Double Resultado = 0.0;

        op2 = Double.parseDouble(temporal);
        op1 = Double.parseDouble(operando1);

        switch (operador) {
            case "mas":
                Resultado = op1 + op2;
                resultado.setText(Double.toString(Resultado));

                break;
            case "res":
                Resultado = op1 - op2;
                resultado.setText(Double.toString(Resultado));

                break;
            case "mul":
                Resultado = op1 * op2;
                resultado.setText(Double.toString(Resultado));

                break;
            case "div":
                Resultado = op1 / op2;
                resultado.setText(Double.toString(Resultado));

                break;

        }


    }


    public void habilitar(Boolean habilita) {

        if (habilita == true) {

            mas.setEnabled(true);
            res.setEnabled(true);
            mul.setEnabled(true);
            div.setEnabled(true);



        } else {
            mas.setEnabled(false);
            res.setEnabled(false);
            mul.setEnabled(false);
            div.setEnabled(false);
            pun.setEnabled(false);
        }


    }


}
